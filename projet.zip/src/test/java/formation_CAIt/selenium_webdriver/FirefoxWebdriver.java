package formation_CAIt.selenium_webdriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class FirefoxWebdriver {

	@Test
	public static void startFirefoxDriver() {

		System.setProperty("webdriver.gecko.driver", "C:\\webdrivers\\geckodriver.exe");
		/* ceci est un commentaire */
		/// * ceci est un commentaire */
		WebDriver driver = new FirefoxDriver(); // initialisation de l'instance du driver
		driver.get("https://www.google.fr"); // demarrage du navigateur
		driver.quit(); // Fermeture du navigateur

	}

}
