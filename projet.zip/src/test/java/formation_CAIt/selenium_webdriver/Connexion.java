package formation_CAIt.selenium_webdriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Connexion {
	private static WebDriver driver;

	@BeforeClass(alwaysRun = true)
	public static void startGeckoDriver() throws Exception {
		
		System.setProperty("webdriver.gecko.driver", "C:\\webdrivers\\geckodriver.exe");
		//WebDriver driver = new FirefoxDriver(); //initialisation de l'instance du driver
		driver = new FirefoxDriver();
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testConnexion() throws Exception {
		driver.get("http://127.0.0.1/orangehrm-4.3.5/symfony/web/index.php/auth/login");
		driver.findElement(By.id("divLogo")).click();
		driver.findElement(By.id("txtUsername")).click();
		driver.findElement(By.name("txtUsername")).sendKeys("CBEGUIN");
		driver.findElement(By.name("txtPassword")).click();
		driver.findElement(By.name("txtPassword")).sendKeys("Chaise1212*");
		driver.findElement(By.id("btnLogin")).click();
	}
	
	public static WebDriver getDriver() {
		return driver;
	}

}
